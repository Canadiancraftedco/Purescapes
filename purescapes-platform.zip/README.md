# PUREscapes Procurement Platform
## Deployment Guide

---

## Architecture

```
werepure.ca (Vercel)
  ├── / → Public website (purescapes-public.html)
  ├── /admin → React Dashboard (purescapes-final.jsx)
  └── /api/scrape → Cron scraper (runs daily 6am ET)

Cloudflare Worker → proxies Anthropic API (fixes CORS)
Supabase (ca-central-1) → database + auth
```

---

## Step 1 — Deploy Cloudflare Worker (AI Proxy)

This fixes the AI assistant so it works everywhere.

1. Go to https://workers.cloudflare.com → **Create Worker**
2. Name it: `purescapes-ai`
3. Paste entire contents of `cloudflare-worker.js`
4. Click **Settings → Variables → Add variable**:
   - Name: `ANTHROPIC_API_KEY`
   - Value: your Anthropic API key (from console.anthropic.com)
5. **Deploy**
6. Copy your worker URL: `https://purescapes-ai.YOUR-ACCOUNT.workers.dev`
7. Update `AI_PROXY` constant in `purescapes-final.jsx` with your actual URL

---

## Step 2 — Set Supabase Environment Variables

In your Supabase project (vrdcpahwapmuyulsfvst):
1. Go to **Settings → API**
2. Copy:
   - **Project URL**: `https://vrdcpahwapmuyulsfvst.supabase.co`
   - **anon key**: already in the app
   - **service_role key**: needed for the scraper (keep secret)

---

## Step 3 — Deploy to Vercel

### Option A: Deploy via Vercel CLI (recommended)
```bash
npm i -g vercel
cd purescapes/
vercel --prod
```

### Option B: Connect GitHub repo
1. Push these files to a GitHub repo
2. Go to vercel.com → **New Project** → Import from GitHub
3. Framework: **Vite** (or Other)
4. Root directory: `/`

### Environment Variables to set in Vercel:
| Variable | Value |
|---|---|
| `SUPABASE_URL` | `https://vrdcpahwapmuyulsfvst.supabase.co` |
| `SUPABASE_SERVICE_KEY` | Your Supabase service_role key |
| `ANTHROPIC_API_KEY` | Your Anthropic API key |
| `CRON_SECRET` | Any random string (e.g. `pure2026secret`) |
| `VITE_AI_PROXY` | Your Cloudflare Worker URL |

---

## Step 4 — Connect werepure.ca domain

1. In Vercel project → **Settings → Domains**
2. Add `werepure.ca` and `www.werepure.ca`
3. Update DNS at your registrar:
   - `A record` → `76.76.21.21`
   - `CNAME www` → `cname.vercel-dns.com`

---

## How the Daily Scraper Works

`vercel.json` configures a cron job:
```json
"crons": [{ "path": "/api/scrape", "schedule": "0 10 * * *" }]
```

This fires `/api/scrape` every day at **10:00 UTC (6am ET)**.

The scraper:
1. Hits Grey County, Meaford, MERX, Georgian Bluffs portals
2. Filters for excavation/landscaping/maintenance keywords
3. Deduplicates against existing Supabase records
4. Sends each new tender to Claude for scoring (0–100 fit score)
5. Inserts scored tenders into Supabase
6. Marks tenders past closing date as `closed`
7. Logs the run to `scrape_log` table

**To trigger manually** (after deployment):
```
GET https://werepure.ca/api/scrape?secret=YOUR_CRON_SECRET
```

---

## Adding More Scrape Sources

Edit `api/scrape.js` — add a new async function following the same pattern as `scrapeGreyCounty()` and add it to the `allRaw` array in the main handler.

Key sources to add:
- `collingwood.bidsandtenders.ca`
- `owensound.bidsandtenders.ca`
- `thebluemountains.bidsandtenders.ca`
- `simcoecounty.bidsandtenders.ca`
- `wasagabeach.bidsandtenders.ca`

---

## Supabase Project
- **Project**: purescapes-procurement
- **Region**: ca-central-1 (Canada)
- **URL**: https://vrdcpahwapmuyulsfvst.supabase.co
- **Dashboard**: https://supabase.com/dashboard/project/vrdcpahwapmuyulsfvst
