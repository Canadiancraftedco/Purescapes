/**
 * PUREscapes AI Proxy — Cloudflare Worker
 * Deploy at: https://workers.cloudflare.com
 * Routes: /v1/messages → Anthropic API
 *
 * DEPLOY STEPS:
 * 1. Go to https://workers.cloudflare.com → Create Worker
 * 2. Paste this entire file
 * 3. Settings → Variables → Add: ANTHROPIC_API_KEY = your key
 * 4. Deploy → copy your worker URL (e.g. https://purescapes-ai.YOUR-NAME.workers.dev)
 * 5. Set VITE_AI_PROXY in your Vercel env vars to that URL
 */

const ANTHROPIC = "https://api.anthropic.com";

// Allowed origins — add your Vercel domain when live
const ALLOWED = [
  "https://claude.ai",
  "https://www.werepure.ca",
  "https://werepure.ca",
  /\.vercel\.app$/,
];

function isAllowed(origin) {
  if (!origin) return true;
  return ALLOWED.some(o =>
    typeof o === "string" ? o === origin : o.test(origin)
  );
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";

    // CORS preflight
    if (request.method === "OPTIONS") {
      return new Response(null, {
        headers: {
          "Access-Control-Allow-Origin": isAllowed(origin) ? origin : "",
          "Access-Control-Allow-Methods": "POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, anthropic-version",
          "Access-Control-Max-Age": "86400",
        },
      });
    }

    if (request.method !== "POST") {
      return new Response("Method not allowed", { status: 405 });
    }

    if (!isAllowed(origin)) {
      return new Response("Forbidden", { status: 403 });
    }

    try {
      const body = await request.json();

      const upstream = await fetch(`${ANTHROPIC}/v1/messages`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify(body),
      });

      const data = await upstream.json();

      return new Response(JSON.stringify(data), {
        status: upstream.status,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": isAllowed(origin) ? origin : "",
        },
      });
    } catch (err) {
      return new Response(JSON.stringify({ error: err.message }), {
        status: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": isAllowed(origin) ? origin : "",
        },
      });
    }
  },
};
