/**
 * PUREscapes Procurement Scraper — Vercel Cron Function
 * File: /api/scrape.js
 *
 * Schedule: Daily at 6:00 AM ET (configured in vercel.json)
 * Also callable manually: GET /api/scrape?secret=YOUR_CRON_SECRET
 *
 * What it does:
 * 1. Fetches open tenders from Grey County, Bids&Tenders, MERX, Biddingo
 * 2. Deduplicates against existing Supabase records
 * 3. Scores each new tender with Claude AI (fit score 0-100)
 * 4. Inserts new tenders + marks closed ones as expired
 * 5. Logs the scrape run to scrape_log table
 */

const SUPA_URL = process.env.SUPABASE_URL;
const SUPA_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY; // service role key — not anon
const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY;

// ── Supabase helper ──────────────────────────────────────────────────────────
async function supa(path, opts = {}) {
  const res = await fetch(`${SUPA_URL}/rest/v1${path}`, {
    headers: {
      apikey: SUPA_SERVICE_KEY,
      Authorization: `Bearer ${SUPA_SERVICE_KEY}`,
      "Content-Type": "application/json",
      Prefer: "return=representation",
      ...(opts.headers || {}),
    },
    ...opts,
  });
  const text = await res.text();
  return text ? JSON.parse(text) : [];
}

// ── Claude scorer ────────────────────────────────────────────────────────────
async function scoreTender(tender) {
  const prompt = `You are scoring a procurement tender for PUREscapes Ltd., a landscaping, hardscaping and excavation contractor in Meaford, Ontario.

Company profile:
- Services: Excavation, grading, site prep, ditch maintenance, armour stone, retaining walls, interlock, landscaping, garden maintenance, snow removal, road brushing
- Equipment: Excavator, Skid Steer, Tractor, Dump Truck, Tow-Behind Mower
- Crew: 6 people, 2 active crews max concurrent
- Rate card: Labour $85/hr, Excavator $165/hr, Tractor $95/hr, Markup 18%
- Location: Meaford ON — radius 100km

TENDER TO SCORE:
Title: ${tender.title}
Municipality: ${tender.municipality}
Category: ${tender.category}
Description: ${tender.description}
Estimated Value: $${tender.estimated_value_low || 0}–$${tender.estimated_value_high || 0}
Distance: ${tender.distance_km || "unknown"}km
Requires Bonding: ${tender.requires_bonding ? "Yes" : "No"}

Respond ONLY with valid JSON (no markdown, no explanation):
{
  "fit_score": <integer 0-100>,
  "reasoning": "<2 sentences why this score>",
  "recommended_bid": <number or null>,
  "strategy_notes": "<1-2 sentences on how to win this>",
  "category": "<one of: excavation|landscaping|maintenance|construction|hardscaping|other>"
}`;

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 400,
      messages: [{ role: "user", content: prompt }],
    }),
  });

  const data = await res.json();
  const text = data.content?.find(c => c.type === "text")?.text || "{}";
  try {
    return JSON.parse(text.replace(/```json|```/g, "").trim());
  } catch {
    return { fit_score: 50, reasoning: "Could not score", recommended_bid: null, strategy_notes: "", category: "other" };
  }
}

// ── Scrapers ─────────────────────────────────────────────────────────────────

// Grey County — public purchasing portal (no auth required for listing)
async function scrapeGreyCounty() {
  const tenders = [];
  try {
    const res = await fetch("https://www.grey.ca/government/budget-finances-purchasing/bids-tenders-contracts", {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; PUREscapes-Bot/1.0)" }
    });
    const html = await res.text();

    // Parse tender blocks from the HTML
    // Grey County uses a standard Drupal view with repeating patterns
    const titleRegex = /Name:\s*([^\n·]+?)[\n·]/g;
    const descRegex = /Description:\s*([^Project]+)/g;
    const closeRegex = /Project closes\s*([\w]+ \d+, \d{4} \d+:\d+ [AP]M [A-Z]+)/g;
    const refRegex = /Reference #:\s*([\w-]+)/g;

    let titleMatch, descMatch, closeMatch, refMatch;
    const titles = [], descs = [], closes = [], refs = [];

    while ((titleMatch = titleRegex.exec(html)) !== null) titles.push(titleMatch[1].trim());
    while ((descMatch = descRegex.exec(html)) !== null) descs.push(descMatch[1].trim().slice(0, 300));
    while ((closeMatch = closeRegex.exec(html)) !== null) closes.push(closeMatch[1].trim());
    while ((refMatch = refRegex.exec(html)) !== null) refs.push(refMatch[1].trim());

    for (let i = 0; i < titles.length; i++) {
      const title = titles[i];
      if (!title || title.length < 5) continue;

      // Filter to relevant categories
      const lower = title.toLowerCase() + " " + (descs[i] || "").toLowerCase();
      const relevant = [
        "excavat", "grad", "ditch", "culvert", "landscap", "mowing", "grass",
        "vegetation", "road", "shoulder", "stone", "site prep", "drainage",
        "erosion", "shoreline", "brushing", "maintenance", "grounds", "park"
      ].some(kw => lower.includes(kw));

      if (!relevant) continue;

      tenders.push({
        title,
        municipality: "Grey County",
        description: descs[i] || "",
        closing_date: closes[i] ? new Date(closes[i]).toISOString() : null,
        tender_number: refs[i] || null,
        source_url: "https://www.grey.ca/government/budget-finances-purchasing/bids-tenders-contracts",
        status: "open",
        distance_km: 15,
      });
    }
  } catch (e) {
    console.error("Grey County scrape error:", e.message);
  }
  return tenders;
}

// Bids & Tenders — Meaford portal
async function scrapeMeaford() {
  const tenders = [];
  try {
    const res = await fetch("https://meaford.bidsandtenders.ca/Module/Tenders/en", {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; PUREscapes-Bot/1.0)" }
    });
    const html = await res.text();

    // Bids&Tenders renders a table — extract rows
    const rowRegex = /<tr[^>]*>.*?<\/tr>/gs;
    const cellRegex = /<td[^>]*>(.*?)<\/td>/gs;
    const linkRegex = /href="([^"]+Tender\/Detail[^"]+)"/;
    const rows = html.match(rowRegex) || [];

    for (const row of rows) {
      const cells = [...row.matchAll(cellRegex)].map(m =>
        m[1].replace(/<[^>]+>/g, "").trim()
      );
      if (cells.length < 3) continue;

      const title = cells[0] || cells[1];
      if (!title || title.length < 5) continue;

      const lower = title.toLowerCase();
      const relevant = ["excavat","grad","landscap","mow","grass","ditch","ground","maintenance","park","construction","drain","stone"].some(k => lower.includes(k));
      if (!relevant) continue;

      const linkMatch = row.match(linkRegex);
      const url = linkMatch ? `https://meaford.bidsandtenders.ca${linkMatch[1]}` : "https://meaford.bidsandtenders.ca/Module/Tenders/en";

      // Find a date cell
      const dateCell = cells.find(c => /\d{4}/.test(c) && /jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec/i.test(c));

      tenders.push({
        title: title.slice(0, 200),
        municipality: "Municipality of Meaford",
        description: cells[1] || title,
        closing_date: dateCell ? new Date(dateCell).toISOString() : null,
        source_url: url,
        status: "open",
        distance_km: 2,
      });
    }
  } catch (e) {
    console.error("Meaford scrape error:", e.message);
  }
  return tenders;
}

// MERX — public Ontario tenders (keyword search via URL)
async function scrapeMERX() {
  const tenders = [];
  const keywords = ["excavation", "landscaping", "grading", "ditch", "grass cutting", "grounds maintenance"];

  for (const kw of keywords.slice(0, 2)) { // limit to 2 per run to avoid rate limits
    try {
      const url = `https://www.merx.com/public/solicitations/ontario-355?keywords=${encodeURIComponent(kw)}&status=open`;
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 (compatible; PUREscapes-Bot/1.0)" }
      });
      const html = await res.text();

      // Extract solicitation cards
      const cardRegex = /class="solicitation-title"[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
      const dateRegex = /Closes?:?\s*([\w]+ \d+, \d{4})/g;

      let match;
      const links = [];
      while ((match = cardRegex.exec(html)) !== null) {
        links.push({ url: `https://www.merx.com${match[1]}`, title: match[2].replace(/<[^>]+>/g,"").trim() });
      }

      const dates = [...html.matchAll(dateRegex)].map(m => m[1]);

      links.forEach((l, i) => {
        if (!l.title || l.title.length < 5) return;
        tenders.push({
          title: l.title.slice(0, 200),
          municipality: "Ontario (MERX)",
          description: `Found via keyword: ${kw}`,
          closing_date: dates[i] ? new Date(dates[i]).toISOString() : null,
          source_url: l.url,
          status: "open",
          distance_km: null,
        });
      });

      await new Promise(r => setTimeout(r, 1000)); // rate limit delay
    } catch (e) {
      console.error("MERX scrape error:", e.message);
    }
  }
  return tenders;
}

// Georgian Bluffs — simple municipal site
async function scrapeGeorgianBluffs() {
  const tenders = [];
  try {
    const res = await fetch("https://www.georgianbluffs.ca/en/business/purchasing-and-tenders.aspx", {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; PUREscapes-Bot/1.0)" }
    });
    const html = await res.text();
    const linkRegex = /<a[^>]+href="([^"]+\.pdf[^"]*)"[^>]*>([\s\S]*?)<\/a>/gi;
    let m;
    while ((m = linkRegex.exec(html)) !== null) {
      const title = m[2].replace(/<[^>]+>/g,"").trim();
      if (!title || title.length < 5) continue;
      const lower = title.toLowerCase();
      if (!["excavat","grad","landscap","mow","grass","ditch","ground","maintenance","road","brush"].some(k=>lower.includes(k))) continue;
      tenders.push({
        title: title.slice(0,200),
        municipality: "Township of Georgian Bluffs",
        description: title,
        closing_date: null,
        source_url: m[1].startsWith("http") ? m[1] : `https://www.georgianbluffs.ca${m[1]}`,
        status: "open",
        distance_km: 18,
      });
    }
  } catch (e) {
    console.error("Georgian Bluffs scrape error:", e.message);
  }
  return tenders;
}

// ── Dedup against existing ───────────────────────────────────────────────────
async function getExistingTitles() {
  const rows = await supa("/tenders?select=title,tender_number&status=eq.open");
  return new Set((Array.isArray(rows) ? rows : []).map(r => r.title.toLowerCase().trim()));
}

// ── Mark expired tenders ─────────────────────────────────────────────────────
async function expireOldTenders() {
  const now = new Date().toISOString();
  await supa(`/tenders?status=eq.open&closing_date=lt.${now}`, {
    method: "PATCH",
    body: JSON.stringify({ status: "closed" }),
    headers: { Prefer: "return=minimal" },
  });
}

// ── Main handler ─────────────────────────────────────────────────────────────
export default async function handler(req, res) {
  // Auth check for manual calls
  if (req.method === "GET") {
    const secret = req.query?.secret;
    if (secret !== process.env.CRON_SECRET) {
      return res.status(401).json({ error: "Unauthorized" });
    }
  }

  console.log(`[PUREscapes Scraper] Starting run at ${new Date().toISOString()}`);

  // Log scrape start
  const logRows = await supa("/scrape_log", {
    method: "POST",
    body: JSON.stringify({ status: "running", started_at: new Date().toISOString() }),
  });
  const logId = Array.isArray(logRows) && logRows[0] ? logRows[0].id : null;

  let totalFound = 0, totalNew = 0;

  try {
    // Expire stale tenders first
    await expireOldTenders();

    // Get existing to dedup
    const existing = await getExistingTitles();

    // Scrape all sources
    const allRaw = [
      ...await scrapeGreyCounty(),
      ...await scrapeMeaford(),
      ...await scrapeMERX(),
      ...await scrapeGeorgianBluffs(),
    ];

    totalFound = allRaw.length;
    console.log(`[Scraper] Found ${totalFound} raw tenders across all sources`);

    // Dedup
    const fresh = allRaw.filter(t => !existing.has(t.title.toLowerCase().trim()));
    console.log(`[Scraper] ${fresh.length} new after dedup`);

    // Score and insert each new tender
    for (const tender of fresh) {
      try {
        const score = await scoreTender(tender);

        await supa("/tenders", {
          method: "POST",
          body: JSON.stringify({
            ...tender,
            category: score.category || "other",
            ai_fit_score: score.fit_score || 50,
            ai_fit_reasoning: score.reasoning || "",
            ai_recommended_bid: score.recommended_bid || null,
            ai_strategy_notes: score.strategy_notes || "",
            ai_scored_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }),
          headers: { Prefer: "return=minimal" },
        });

        totalNew++;
        await new Promise(r => setTimeout(r, 500)); // rate limit Claude calls
      } catch (e) {
        console.error(`[Scraper] Failed to insert "${tender.title}":`, e.message);
      }
    }

    // Update scrape log
    if (logId) {
      await supa(`/scrape_log?id=eq.${logId}`, {
        method: "PATCH",
        body: JSON.stringify({
          status: "success",
          completed_at: new Date().toISOString(),
          tenders_found: totalFound,
          tenders_new: totalNew,
        }),
        headers: { Prefer: "return=minimal" },
      });
    }

    console.log(`[Scraper] Done. Found: ${totalFound}, New: ${totalNew}`);
    return res.status(200).json({
      success: true,
      tenders_found: totalFound,
      tenders_new: totalNew,
      timestamp: new Date().toISOString(),
    });

  } catch (err) {
    console.error("[Scraper] Fatal error:", err);
    if (logId) {
      await supa(`/scrape_log?id=eq.${logId}`, {
        method: "PATCH",
        body: JSON.stringify({ status: "failed", error_message: err.message, completed_at: new Date().toISOString() }),
        headers: { Prefer: "return=minimal" },
      });
    }
    return res.status(500).json({ error: err.message });
  }
}
